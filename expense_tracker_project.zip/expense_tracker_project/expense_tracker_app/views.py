from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Expense

def index(request):
    expenses = Expense.objects.all()
    total_expenses = 0
    for expense in expenses:
        total_expenses += expense.amount
    context = {
        'expenses': expenses,
        'total_expenses': total_expenses
    }
    return render(request, 'expense_tracker_app/index.html', context)

def add_expense(request):
    if request.method == 'POST':
        name = request.POST['name']
        amount = request.POST['amount']
        category = request.POST['category']
        expense = Expense(name=name, amount=amount, category=category)
        expense.save()
    return redirect('index')

def delete_expense(request, expense_id):
    expense = Expense.objects.get(id=expense_id)
    expense.delete()
    return redirect('index')
    