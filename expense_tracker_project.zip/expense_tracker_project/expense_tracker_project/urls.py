from django.urls import path
from expense_tracker_app import views

urlpatterns = [
    path('', views.index, name='index'),
    path('add-expense/', views.add_expense, name='add_expense'),
    path('delete-expense/<int:expense_id>/', views.delete_expense, name='delete_expense')

]
